#define NDEBUG
#include <GL/glut.h>
#include <iostream>
using namespace std;

void MidPointLine(int x1, int y1, int xn, int yn)
{
    int dx, dy, d1, d2, d, x, y;
    dx = xn - x1;
    dy = yn - y1;
    d = dx - 2 * dy;           //
    d1 = 2* dx - 2* dy;         //
    d2 = -2* dy;             //
    x = x1; y = y1;
    //putpixel(x, y);
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    //glEnd();
    while (x < xn)
    {
        if (d < 0)
        {
            x++;
            y++;
            d += d1;
        }
        else
        {
            x++;
            d += d2;
        }
        //putpixel(x, y);        
        glVertex2i(x, y);        
    }
    glEnd();
}

void Init()
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_SMOOTH);
}
void myReshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, (GLdouble)w, 0.0, (GLdouble)h);
}

void myDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0f, 0.0f, 0.0f);
	//LineDDA(0, 0, 300, 200);
	MidPointLine(10, 50, 300, 260);
	glFlush();
}

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(400, 400);
	glutCreateWindow("Hello World!");
	Init();
	glutDisplayFunc(myDisplay);
	glutReshapeFunc(myReshape);
	glutMainLoop();
	return 0;
}